<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
     $a=10;
     $b=20;
     $c=$a+$b;
     $d=$a-$b;
     $e=$a*$b;
     $f=$a/$b;
     echo "<h1>addition</h1>";
     echo "a=",$a;
     echo "<br>";
     echo  "b=",$b;
     echo "<br>";
     echo "addition is= ",$c;
     echo "<br>";
     echo "<h1>substract</h1>";
     echo "a=",$a;
     echo "<br>";
     echo  "b=",$b;
     echo "<br>";
     echo "substract is=",$d;
     echo "<br>";
     echo "<h1>multiplication</h1>";
     echo "multiplie is=",$e;
     echo "<br>";
     echo "<h1>division</h1>";
     echo "division is=",$f;
     ?>
</body>
</html>