<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    echo "Hello"."<br>";
    echo "how are you?"."<br>";
    print "how are you?";
    $a=10;
    echo "<br>";
    echo "value of a=",$a;
    $b=20;
    $c=$a+$b;
    echo "<h1>addition</h1>";
    echo "a=",$a;
    echo "<br>";
    echo  "b=",$b;
    echo "<br>";
    echo "addition is= ",$c;
    ?>
</body>
</html>