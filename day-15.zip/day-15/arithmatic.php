<?php
$a=10;
$b=20;
$c=$a+$b;
echo "<h1>addition</h1>";
echo "a=",$a;
echo "<br>";
echo  "b=",$b;
echo "<br>";
echo "addition is= ",$c
?>