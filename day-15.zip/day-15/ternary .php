<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $a=15;
    $b=25;
    $c=30;
     echo ($a>$b)?("<br>" .$a. "is greater"):("<br>" .$b. "is greater");
    // if($a>$b && $a>$c)
    // {
    // echo $a."is greater"."<br>";
    // }
    // else if($b>$c)
    // {
    //  echo$b. "is greater";        
    // }
    // else
    // {
    //     echo $c."is greater";
    // }
    ?>
</body>
</html>