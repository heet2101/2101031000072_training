<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $a=array(1,2,3,4,5,6);
    // echo "array=".$a[0];
    // echo "array=".$a[1];
    // echo "array=".$a[2];
    // echo "array=".$a[3];
    // echo "array=".$a[4];
    // echo "array=".$a[5];
    print_r($a);
    echo "<br>";
    $sum=0;
    foreach($a as $values)
    {
        $sum=$sum+$values;
        echo $sum ."<br>";
    }
    ?>

</body>
</html>