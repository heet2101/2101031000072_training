<?php
$username = $_POST['username'];
$password = $_POST['password'];
echo $username ."<br>";
echo $password;
?>